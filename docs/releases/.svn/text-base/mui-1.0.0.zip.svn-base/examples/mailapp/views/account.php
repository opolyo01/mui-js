<div id="account">
	<ul>
		<li class="mui-list-item mui-selectable arrow">
			<div class="icon inbox"></div>
			<div class="mui-title">Inbox</div>
			<div class="message-count">26</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="icon draft"></div>
			<div class="mui-title">Drafts</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="icon sent"></div>
			<div class="mui-title">Sent</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="icon trash"></div>
			<div class="mui-title">Trash</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="icon folder"></div>
			<div class="mui-title">Archive</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="icon folder"></div>
			<div class="mui-title">Bulk Mail</div>
		</li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
	</ul>
</div>