<?php
/**
 * CVS version tag to appease CodeSniffer
 * @version CVS: $Id: |       | VersionCvsIdTagSniff.php,v 1.2 2999/11/11 00:00:00 matth Exp $
 */

 sleep(2); ?>
{
	"property1": "value1",
	"property2": "value2"
}