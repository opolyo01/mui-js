<div id="message-list">
	<!--<h2><?php echo $_GET['fid']; ?></h2>-->
	<ul>
		<li class="mui-list-item mui-selectable arrow new-message">
			<div class="message-preview">
				<div class="mui-title">foursquare!</div>
				<div class="date"><strong>5:23</strong> PM</div>
				<div class="message-title">foursquare :: You just unlocked the Bender badge!</div>
				<div class="summary">
					Hey there - Congrats! Your checkin to Turmeric Restaurant just unlocked Bender...
				</div>
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow new-message">
			<div class="message-preview">
				<div class="mui-title">Twitter</div>
				<div class="date"><strong>3:59</strong> PM</div>
				<div class="message-title">CarrieJohnston is now following you on Twitter</div>
				<div class="summary">
					Hi, m1k3l. CarrieJohnston (Johnston_4050) is now following your tweets on Twitter. A...
				</div>
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow new-message">
			<div class="message-preview">			
				<div class="mui-title">Eventful</div>
				<div class="date">Yesterday</div>
				<div class="message-title">[New] The Reel Buzz - Find showtimes in your area</div>
				<div class="summary">
					MOVIE HOME SHOWTIMES BROWSE MOVIES FIND EVENTS SEARCH mjohns...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">customerserviceonline@pge.com</div>
				<div class="date">Yesterday</div>
				<div class="message-title">PG&E: You have a New Energy Statement Online</div>
				<div class="summary">
					Dear Valued Customer, A new energy statement for you PG&E account ******2...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">TurboTax Online</div>
				<div class="date">Yesterday</div>
				<div class="message-title">TurboTax User ID: E-file Now Available</div>
				<div class="summary">
					E-file now available. Don't delay your refund. Not seeing images? View mobile...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">Chris Lowe</div>
				<div class="date">Yesterday</div>
				<div class="message-title">Why you should come to ukraine this summer</div>
				<div class="summary">
					http://www.kazantip.com/gallery This is just a little music festival that takes place in a ...
				</div>			
			</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="message-preview">			
				<div class="mui-title">The SnowBomb Team</div>
				<div class="date">Yesterday</div>
				<div class="message-title">SnowBomb January Deals!!!</div>
				<div class="summary">
					SnowBomb Membership E-Nes - Volume 14 - Issue 01 - January 8, 2010 DEAL AL...
				</div>			
			</div>
		</li>
	</ul>
</div>