/**
 * TabView module
 * @module tab-view
 */

(function() {

const CLASS_SHOWING = 'mui-showing';

/**
 * The TabView class provides a tabbed navigation model for related
 * contents. TabViews can be embedded inside the header of a page for
 * global navigation, or inside the content of the page
 * @class TabView
 * @constructor
 * @param el {String|HTMLElement} CSS Selector or HTMLElement for the tabs container
 * @param options {Object} TabView configuration options
 */
function TabView(el, options)
{
	// Declare locals
	var active = null;
	options = options || {};
	
	// Initialize element
	this.element = mui.get(el);
	mui.addClass(this.element, 'mui-tab-view');
	
	// Initialize list
	this.tabs = mui.getAll('li', this.element);
	mui.each(this.tabs, function(t) {
		t.style.width = Math.round(100/this.tabs.length)+'%';
	}, this);
	
	// Check active index
	active = mui.get('.mui-showing', this.element);
	this.activeIndex = active ? this.tabs.indexOf(active) : 0;
	if(!mui.hasClass(this.tabs[this.activeIndex], CLASS_SHOWING)) mui.addClass(this.tabs[this.activeIndex], CLASS_SHOWING);

	// Iniitalize tabContents
	this.tabContents = [];
	if(options.tabContents)
	{
		mui.each(options.tabContents, function(tc, i) {
			var el = mui.get(tc);
			mui.addClass(el, 'mui-tab-content');
			if(i === this.activeIndex)
			{
				mui.addClass(el, CLASS_SHOWING);
			}
			this.tabContents.push(mui.get(tc));
		}, this);
	}
	
	// Initialize events
	mui.on(this.element, 'click', this);
}

TabView.prototype = {

	/**
	 * The HTMLElement containing the tabs
	 * @property element
	 * @type HTMLElement
	 */
	element: null,
	
	/**
	 * The index of the currently selected tab
	 * @property activeIndex
	 * @type Number
	 */
	activeIndex: null,
	
	/**
	 * Array of elements which are the contents for each tab
	 * @property tabContents
	 * @type Array
	 */
	tabContents: null,
	
	/**
	 * DOM Event handler
	 * @method handleEvent
	 * @param e {Event} The DOM event
	 * @private
	 */
	handleEvent: function(e)
	{
		var tabTarget = mui.getAncestorByTagName(e.target, 'li');
		if(!tabTarget) return false;
		switch(e.type)
		{
			case 'click':
				e.preventDefault();
				
				var active = mui.get('.mui-showing', this.element);
				if(active && tabTarget === active)
				{
					this.tabRefreshed(this.activeIndex);
				}
				else if(active && tabTarget !== active)
				{
					this.activateTabAtIndex(this.tabs.indexOf(tabTarget)).tabChanged(this.activeIndex);
				}
				break;
		}
	},
	
	/**
	 * Tab change event handler which is invoked every time a tab is activated.
	 * Override this method in implementation. The first argument to the method
	 * is the index of the selected tab.
	 * @method tabChanged
	 * @param index {Number} The index of the selected tab
	 */
	tabChanged: function(index)
	{
		// Override this method
	},
	
	/**
	 * This method is invoked whenever the currently active tab is reactivated.
	 * Override this method in implementation. The first argument to the method
	 * is the index of the selected tab.
	 * @method tabRefreshed
	 * @param index {Number} The index of the selected tab
	 */
	tabRefreshed: function(index)
	{
		// Override this method	
	},
	
	/**
	 * Set the tabContent for a particular tab at a given index
	 * @method setTabContent
	 * @param index {Number} The index of the tab
	 * @param tabContent {String|HTMLElement} The tabContent element
	 */
	setTabContent: function(index, tabContent)
	{
		this.tabContents[index] = mui.get(tabContent);
	},
	
	/**
	 * Activate a tab at a given index by activating the selected state of the tab, as well
	 * as showing any tab content for the tab
	 * @method activateTabAtIndex
	 * @param index {Number} The index of the tab to activate
	 * @return {mui.TabView} The TabView instance
	 */
	activateTabAtIndex: function(index)
	{
		var active = mui.get('.mui-showing', this.element);
		var activeContent;
		
		this.activeIndex = index;
		
		mui.removeClass(active, CLASS_SHOWING);
		mui.addClass(this.tabs[this.activeIndex], CLASS_SHOWING);

		if(this.tabContents) activeContent = this.tabContents[this.tabs.indexOf(active)];

		if(activeContent)
		{
			mui.removeClass(activeContent, CLASS_SHOWING);
			mui.addClass(this.tabContents[this.activeIndex], CLASS_SHOWING);
		}
		
		return this;
	}
};

mui.TabView = TabView;
	
})();