<?php sleep(1); ?>

<div id="message">
	<div class="header">
		<label>From: </label>
		<span class="sender">foursquare!</span>
	</div>
	
	<div class="subject">
		<strong>foursquare :: You just unlocked the Bender badge!</strong>
		<div class="date">January 6, 2010 5:23 PM</div>
	</div>
	
	<div class="body" style="width:1000px;">
		

		
		Hey there - 
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
		
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare		
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
		
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
		
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you! Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
		
		<br /><br />
		Congrats! Your checkin to Turmeric Restaurant just unlocked the Bender - That's 4+ nights in a row for you!
		<br /><br />
		To see all the badges you've unlocked so far, click here: <a href="http://foursquare.com/user/-193382/badges/401861">http://foursquare.com/user/-193382/badges/401861</a>
		<br /><br />
		- foursquare
	</div>
</div>