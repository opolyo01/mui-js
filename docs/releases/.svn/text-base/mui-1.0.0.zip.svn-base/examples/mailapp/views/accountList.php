<div id="accounts-list">
	<ul>
		<li class="mui-list-item mui-selectable arrow">
			<div class="mui-title">Yahoo!</div>
			<div class="message-count">26</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="mui-title">Y! Corp</div>
		</li>
		<li class="mui-list-item mui-selectable arrow">
			<div class="mui-title">Gmail</div>
			<div class="message-count">3</div>
		</li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>
		<li class="mui-list-item"></li>		
	</ul>
</div>